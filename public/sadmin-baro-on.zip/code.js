'use strict';

const componentList = [
    { name: 'table', type: 'INSTANCE', exeType: 'tag' },
    { name: 'thead', type: 'INSTANCE', exeType: 'tag' },
    { name: 'tbody', type: 'INSTANCE', exeType: 'tag' },
    { name: 'tr', type: 'INSTANCE', exeType: 'tag' },
    { name: 'th', type: 'INSTANCE', exeType: 'tag' },
    { name: 'td', type: 'INSTANCE', exeType: 'tag' },
    { name: 'section', type: 'INSTANCE', exeType: 'tag' },
    { name: 'article', type: 'INSTANCE', exeType: 'tag' },
    { name: 'h1', type: 'INSTANCE', exeType: 'tag' },
    { name: 'h2', type: 'INSTANCE', exeType: 'tag' },
    { type: 'TEXT', exeType: 'text' },
    { type: 'COMPONENT', exeType: 'component' },
];
//# sourceMappingURL=componentList.js.map

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getComponent(node, depth) {
    var _a;
    //Properties
    let prop = '';
    let res = '';
    const nl = depth > 0 ? `\n` : '';
    let res_start = '';
    let res_end = '';
    let res_component = '';
    const name = node.name;
    if (node.children && ((_a = node.children) === null || _a === void 0 ? void 0 : _a.length) > 0) {
        let label = '';
        let guideText = '';
        let fieldClass = '';
        if (['Gnb', 'Lnb', 'Titlebar'].includes(name)) { // Gnb, Lnb, Titlebar
            res_component = `<${name} />`;
        } // Gnb, Lnb, Titlebar
        else if (name === 'Button') { // Button
            const color = node.componentProperties.class.value;
            const style = node.componentProperties.style.value;
            let inputClass = color === 'basic' ? '' : ` ${color}`;
            inputClass += style === 'basic' ? '' : ` ${style}`;
            let value = '';
            let iconLeft = '';
            let iconRight = '';
            for (const child of node.children) {
                if (child.name === 'button') {
                    value = child.characters;
                }
                else if (child.visible && child.name === 'iconLeft') {
                    iconLeft = ` iconLeft="${child.componentProperties.select.value}"`;
                }
                else if (child.visible && child.name === 'iconRight') {
                    iconRight = ` iconRight="${child.componentProperties.select.value}"`;
                }
            }
            inputClass = inputClass.length > 0 ? ` class="${inputClass.trim()}"` : '';
            prop = `${iconLeft}${iconRight}${inputClass}`;
            res_component = `<${name}${prop}>${value}</${name}>`;
        } // Button
        else if (name === 'Tabs' || name === 'Tabs-is-boxed') { // Tabs
            const tabsArr = [];
            for (const child of node.children) {
                if (child.visible === true) {
                    const obj = new Object();
                    const text = child.children[0].characters;
                    const checked = child.componentProperties.checked.value;
                    obj['name'] = text;
                    if (checked === 'true') {
                        obj['checked'] = true;
                    }
                    tabsArr.push(obj);
                }
            }
            prop = name === 'Tabs-is-boxed' ? ` class="is-boxed"` : '';
            res_component = `<Tabs tabs={${JSON.stringify(tabsArr)}}${prop} />`;
        } // Tabs
        else if (name === 'Field') { // Field
            let labelText = '';
            let requiredText = '';
            for (const child of node.children) {
                if (child.name === 'Title') {
                    labelText = child.characters;
                }
                if (child.name === '*') {
                    requiredText = ' required';
                }
            }
            label = ` label="${labelText}"${requiredText}`;
            res_component = `<Field ${label} />`;
        } // Field
        else { // Components with Field 
            for (const child of node.children) {
                if (child.visible === true) {
                    if (child.name === 'Label') { // Field Label
                        let labelText = '';
                        let requiredText = '';
                        for (const childDepth2 of child.children) {
                            if (childDepth2.name === 'Title') {
                                labelText = childDepth2.characters;
                            }
                            if (childDepth2.name === '*') {
                                requiredText = ' required';
                            }
                        }
                        label = ` label="${labelText}"${requiredText}`;
                    } // Field Label  
                    else if (child.name === 'Guide Text') { // Field Guide Text
                        const color = child.componentProperties.class.value;
                        guideText = ` memo="${child.children[0].characters}"`;
                        fieldClass = color === 'basic' ? '' : ` class="${color}"`;
                    } // Field Guide Text
                    else if (child.name === 'input-class') { // Input
                        const color = child.componentProperties.class.value;
                        let inputClass = color === 'basic' ? '' : ` ${color}`;
                        let placeholder = '';
                        let value = '';
                        let iconLeft = '';
                        let iconRight = '';
                        for (const childDepth2 of child.children) {
                            if (childDepth2.name === 'placeholder') {
                                if (color === 'is-static') {
                                    value = childDepth2.characters;
                                }
                                else {
                                    placeholder = childDepth2.characters;
                                }
                            }
                            else if (childDepth2.visible && childDepth2.name === 'iconLeft') {
                                iconLeft = ` iconLeft="${childDepth2.componentProperties.select.value}"`;
                            }
                            else if (childDepth2.visible && childDepth2.name === 'iconRight') {
                                iconRight = ` iconRight="${childDepth2.componentProperties.select.value}"`;
                            }
                        }
                        value = value.length > 0 ? `value="${value.trim()}"` : '';
                        placeholder = placeholder.length > 0 ? `placeholder="${placeholder.trim()}"` : '';
                        inputClass = inputClass.length > 0 ? ` class="${inputClass.trim()}"` : '';
                        prop = `${value}${placeholder}${iconLeft}${iconRight}${inputClass}`;
                        res_component = `<${name} ${prop} />`;
                    } // Input
                    else if (child.name === 'select-class') { // Select
                        const color = child.componentProperties.class.value;
                        let inputClass = color === 'basic' ? '' : ` ${color}`;
                        let value = '';
                        let iconLeft = '';
                        for (const childDepth2 of child.children[0].children) {
                            if (childDepth2.name === 'text') {
                                value = childDepth2.characters;
                            }
                            else if (childDepth2.visible && childDepth2.name === 'iconLeft') {
                                iconLeft = ` iconLeft="${childDepth2.componentProperties.select.value}"`;
                            }
                        }
                        inputClass = inputClass.length > 0 ? ` class="${inputClass.trim()}"` : '';
                        prop = `${iconLeft}${inputClass}`;
                        res_component = `<${name} ${prop}>`;
                        res_component += `\n` + `  `.repeat(depth + 2) + `<option>${value}</option>`;
                        res_component += `\n` + `  `.repeat(depth + 1) + `</${name}>`;
                    } // Select
                    else if (child.name === 'select-multiple-class') { // Select-multiple
                        prop = child.name === 'select-multiple-class' ? ` multiple size="5"` : '';
                        res_component = `<${name.split('-')[0]} ${prop}>`;
                        res_component += `\n` + `  `.repeat(depth + 2) + `<option>Sample</option>`;
                        res_component += `\n` + `  `.repeat(depth + 1) + `</${name.split('-')[0]}>`;
                    } // Select-multiple
                    else if (child.name === 'textarea-class') { // Textarea
                        const color = child.componentProperties.class.value;
                        let placeholder = child.children[0].characters;
                        prop = color === 'basic' ? '' : ` class="${color}"`;
                        placeholder = placeholder.length > 0 ? ` placeholder="${placeholder.trim()}"` : '';
                        res_component = `<${name}${placeholder}${prop} />`;
                    } // Textarea
                    else if (child.name === 'editor-class') { // Editor
                        let placeholder = child.children[0].children[1].characters;
                        placeholder = placeholder.length > 0 ? ` placeholder="${placeholder.trim()}"` : '';
                        res_component = `<${name}${placeholder} />`;
                    } // Editor
                    else if (child.name === 'toggle-class' || child.name === 'file-class' || child.name === 'file-is-boxed-class') { // Toggle, File
                        const color = child.componentProperties.class.value;
                        const isBoxed = child.name === 'file-is-boxed-class' ? ' is-boxed' : '';
                        prop = color === 'basic' ? '' : ` class="${color}${isBoxed}"`;
                        res_component = `<${name.split('-')[0]}${prop} />`;
                    } // Toggle, File
                    else if (child.name === 'radio-class' || child.name === 'checkbox-class') { // Radio, Checkbox
                        let nl = '';
                        for (const childDepth2 of child.children) {
                            if (childDepth2.visible === true) {
                                let checked = childDepth2.componentProperties.State.value;
                                checked = checked === 'checked' ? ' checked' : '';
                                res_component += nl + `<label>`;
                                res_component += `\n` + `  `.repeat(depth + 2) + `<input type="${child.name.split('-')[0]}"${checked}>`;
                                res_component += `\n` + `  `.repeat(depth + 2) + childDepth2.children[0].children[1].characters;
                                res_component += `\n` + `  `.repeat(depth + 1) + `</label>`;
                                nl = `\n` + `  `.repeat(depth + 1);
                            }
                        }
                    } // Radio, Checkbox
                    else if (child.name === 'date-class') { // Date
                        const color = child.componentProperties.class.value;
                        let inputClass = color === 'basic' ? '' : ` ${color}`;
                        let value = '';
                        let iconLeft = '';
                        for (const childDepth2 of child.children[0].children) {
                            if (childDepth2.name === 'text') {
                                value = childDepth2.characters;
                            }
                            else if (childDepth2.visible && childDepth2.name === 'iconLeft') {
                                iconLeft = ` iconLeft="${childDepth2.componentProperties.select.value}"`;
                            }
                        }
                        value = value.length > 0 ? ` value="${value.trim()}"` : '';
                        inputClass = inputClass.length > 0 ? ` class="${inputClass.trim()}"` : '';
                        prop = `${value}${iconLeft}${inputClass}`;
                        res_component = `<${name}${prop} />`;
                    } // Date
                    else {
                        res_component = `<${name} />`;
                    }
                } // vidible
            } // child loop
            res_start += nl + `  `.repeat(depth) + `<Field${label}${guideText}${fieldClass}>`;
            res_end += `\n` + `  `.repeat(depth) + `</Field>`;
            depth++;
        }
    }
    res = `${res_start}`;
    res += `\n` + `  `.repeat(depth) + res_component;
    res += `${res_end}`;
    return res;
}
//# sourceMappingURL=getComponent.js.map

const get = (node, prefix, depth = 0) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
    const nl = depth > 0 ? `\n` : ``;
    let name = node.name;
    //행열 처리
    if (node.parent.name === 'columns') {
        name = `${prefix}column ${prefix}${name}`;
    }
    let res = '';
    let res_end = '';
    let childSearch = true;
    if (((_a = componentList.filter((el) => el.type === node.type)[0]) === null || _a === void 0 ? void 0 : _a.exeType) === 'text') { //TextNode
        res = nl + `  `.repeat(depth) + node.characters;
        childSearch = false;
    }
    else if (((_b = componentList.filter((el) => el.name === node.name)[0]) === null || _b === void 0 ? void 0 : _b.exeType) === 'tag') { //tag
        res = nl + `  `.repeat(depth) + `<${name}>`;
        //table
        if (name === 'table'
            && ((_c = node.children[0]) === null || _c === void 0 ? void 0 : _c.name) === 'thead'
            && ((_e = (_d = node.children[0]) === null || _d === void 0 ? void 0 : _d.children[0]) === null || _e === void 0 ? void 0 : _e.name) === 'tr'
            && ((_h = (_g = (_f = node.children[0]) === null || _f === void 0 ? void 0 : _f.children[0]) === null || _g === void 0 ? void 0 : _g.children[0]) === null || _h === void 0 ? void 0 : _h.name) === 'th') {
            res += `\n` + `  `.repeat(depth + 1) + `<colgroup>`;
            // eslint-disable-next-line no-unsafe-optional-chaining
            for (const col of (_j = node.children[0]) === null || _j === void 0 ? void 0 : _j.children[0].children) {
                const width = col.layoutGrow === 0 ? col.width : '*';
                res += `\n` + `  `.repeat(depth + 2) + `<col width="${width}">`;
            }
            res += `\n` + `  `.repeat(depth + 1) + `</colgroup>`;
        }
        res_end += `\n` + `  `.repeat(depth) + `</${name}>`;
    }
    else if (((_k = componentList.filter((el) => el.type === node.type)[0]) === null || _k === void 0 ? void 0 : _k.exeType) === 'component' || ((_l = componentList.filter((el) => { var _a; return el.type === ((_a = node.masterComponent) === null || _a === void 0 ? void 0 : _a.type); })[0]) === null || _l === void 0 ? void 0 : _l.exeType) === 'component') { //Component
        res = getComponent(node, depth);
        childSearch = false;
    }
    else if (name !== '_description') {
        res = nl + `  `.repeat(depth) + `<div class="${name}">`;
        res_end += `\n` + `  `.repeat(depth) + `</div>`;
    }
    else {
        childSearch = false;
    }
    //text나 component, _description이 아니면 하위 탐색
    if (childSearch && node.children && ((_m = node.children) === null || _m === void 0 ? void 0 : _m.length) > 0) {
        for (const child of node.children) {
            res += get(child, prefix, depth + 1);
        }
    }
    res += res_end;
    return res;
};
const getCode = (msg) => {
    const prefix = msg.data;
    let data = '';
    let flag = 'fail';
    let message = 'Please select Object';
    if (figma.currentPage.selection.length > 0) {
        for (const node of figma.currentPage.selection) {
            data += get(node, prefix);
        }
        flag = 'success';
        message = '';
    }
    const res = {
        action: 'getCode',
        flag: flag,
        message: message,
        data: data
    };
    figma.ui.postMessage(res);
};
//# sourceMappingURL=getCode.js.map

const get$1 = (device) => {
    const componentPage = figma.root.children.find(el => el.name === '_component');
    let pageFrame = componentPage === null || componentPage === void 0 ? void 0 : componentPage.children.find(el => el.name === '_page');
    if (device === 'mo') {
        pageFrame = componentPage === null || componentPage === void 0 ? void 0 : componentPage.children.find(el => el.name === '_page_mo');
    }
    const page = figma.currentPage;
    if (componentPage === undefined) {
        return { flag: 'errPage', message: 'Can not find _component Page' };
    }
    else if (pageFrame === undefined) {
        return { flag: 'errFrame', message: 'Can not find _page frame' };
    }
    const instance = pageFrame.clone();
    figma.currentPage.appendChild(instance);
    if (page.children.length > 1) {
        const lastChild = page.children.length - 2;
        instance.x = page.children[lastChild].x + page.children[lastChild].width + 1000;
    }
    return { flag: 'success', message: '' };
};
const addPage = (msg, device) => {
    const { flag, message } = get$1(device);
    const res = {
        action: 'addPage',
        flag: flag,
        message: message
    };
    figma.ui.postMessage(res);
};
//# sourceMappingURL=addPage.js.map

const draw = (rule) => {
    const selectedObject = figma.currentPage.selection;
    if (!Array.isArray(rule)) {
        return { flag: 'errArray', message: 'Data is not Array' };
    }
    const sum = rule.reduce((a, b) => a + b, 0);
    if (sum !== 12) {
        return { flag: 'errSum', message: 'The sum of the grid numbers must be 12' };
    }
    if (selectedObject.length === 0) {
        return { flag: 'errSelect', message: 'Please select object' };
    }
    if (selectedObject[0].type !== 'FRAME') {
        return { flag: 'errFrame', message: 'Please select frame' };
    }
    if (selectedObject[0].name === 'columns') {
        return { flag: 'errFrame', message: 'Can\'t draw on columns' };
    }
    let prevSize = rule[0];
    let sameSizeCheck = true;
    for (const obj of rule) {
        if (prevSize !== obj) {
            sameSizeCheck = false;
            break;
        }
        else {
            prevSize = obj;
        }
    }
    const frame = figma.createFrame();
    frame.name = 'columns';
    frame.clipsContent = true;
    frame.primaryAxisSizingMode = "FIXED";
    frame.primaryAxisAlignItems = "MIN";
    frame.layoutMode = "HORIZONTAL";
    if (selectedObject[0].layoutMode === "VERTICAL") {
        frame.layoutGrow = 0;
        frame.layoutAlign = "STRETCH";
    }
    else {
        frame.layoutGrow = 1;
        frame.layoutAlign = "INHERIT";
    }
    frame.primaryAxisAlignItems = "MIN";
    frame.primaryAxisSizingMode = "FIXED";
    frame.counterAxisAlignItems = "MIN";
    frame.counterAxisSizingMode = "AUTO";
    frame.itemSpacing = 10;
    frame.paddingTop = 10;
    frame.paddingBottom = 10;
    frame.verticalPadding = 10;
    for (const obj of rule) {
        const subFrame = figma.createFrame();
        subFrame.name = `is-${obj}`;
        if (sameSizeCheck === true) {
            //auto width
            subFrame.resize(subFrame.width, 30);
            subFrame.layoutGrow = 1;
        }
        else {
            //fixed width
            const width = selectedObject[0].width * obj / 12;
            subFrame.resize(width, 30);
            subFrame.layoutGrow = 0;
        }
        subFrame.clipsContent = true;
        subFrame.primaryAxisSizingMode = "FIXED";
        subFrame.primaryAxisAlignItems = "MIN";
        subFrame.layoutMode = "HORIZONTAL";
        subFrame.layoutPositioning = "AUTO";
        subFrame.layoutAlign = "INHERIT";
        subFrame.counterAxisAlignItems = "MIN";
        subFrame.counterAxisSizingMode = "AUTO";
        subFrame.itemSpacing = 10;
        frame.appendChild(subFrame);
    }
    selectedObject[0].appendChild(frame);
    return { flag: 'success', message: '' };
};
const drawGrid = (msg, rule) => {
    const { flag, message } = draw(rule);
    const res = {
        action: 'drawGrid',
        flag: flag,
        message: message
    };
    figma.ui.postMessage(res);
};
//# sourceMappingURL=drawGrid.js.map

const draw$1 = () => {
    const selectedObject = figma.currentPage.selection;
    if (selectedObject.length === 0) {
        return { flag: 'errSelect', message: 'Please select object' };
    }
    if (selectedObject[0].type !== 'FRAME') {
        return { flag: 'errFrame', message: 'Please select frame' };
    }
    if (selectedObject[0].name === 'columns') {
        return { flag: 'errFrame', message: 'Can\'t draw on columns' };
    }
    if (selectedObject[0].name === 'is-bordered') {
        return { flag: 'errFrame', message: 'Can\'t draw on is-bordered' };
    }
    const frame = figma.createFrame();
    frame.name = 'is-bordered';
    frame.clipsContent = true;
    frame.layoutMode = "VERTICAL";
    if (selectedObject[0].layoutMode === "VERTICAL") {
        frame.layoutGrow = 0;
        frame.primaryAxisSizingMode = "AUTO";
    }
    else {
        frame.layoutGrow = 1;
        frame.primaryAxisSizingMode = "FIXED";
    }
    frame.layoutAlign = "STRETCH";
    frame.primaryAxisAlignItems = "MIN";
    frame.counterAxisAlignItems = "MIN";
    frame.counterAxisSizingMode = "FIXED";
    frame.itemSpacing = 10;
    frame.paddingTop = 10;
    frame.paddingBottom = 10;
    frame.horizontalPadding = 10;
    frame.verticalPadding = 10;
    frame.strokes = [{ type: "SOLID", color: { r: 0.86, g: 0.86, b: 0.86 }, visible: true, opacity: 1, blendMode: "NORMAL" }];
    frame.cornerRadius = 4;
    selectedObject[0].appendChild(frame);
    return { flag: 'success', message: '' };
};
const drawBorderBox = (msg) => {
    const { flag, message } = draw$1();
    const res = {
        action: 'drawBorderBox',
        flag: flag,
        message: message
    };
    figma.ui.postMessage(res);
};
//# sourceMappingURL=drawBorderBox.js.map

const getInfo = (msg) => {
    const selectedObject = figma.currentPage.selection;
    console.log(selectedObject);
    const res = {
        action: 'getInfo',
        flag: 'success'
    };
    figma.ui.postMessage(res);
};
//# sourceMappingURL=getInfo.js.map

const get$2 = (name) => {
    const selectedObject = figma.currentPage.selection;
    const componentPage = figma.root.children.find(el => el.name === '_component');
    const pageFrame = componentPage === null || componentPage === void 0 ? void 0 : componentPage.children.find(el => el.name === '_component');
    const baseComponent = pageFrame === null || pageFrame === void 0 ? void 0 : pageFrame.children.find(el => el.name === name);
    if (selectedObject.length === 0) {
        return { flag: 'errSelect', message: 'Please select object' };
    }
    else if (selectedObject[0].type !== 'FRAME') {
        return { flag: 'errFrame', message: 'Please select frame' };
    }
    else if (selectedObject[0].name === 'columns') {
        return { flag: 'errFrame', message: 'Can\'t draw on columns' };
    }
    else if (selectedObject[0].name === 'is-bordered') {
        return { flag: 'errFrame', message: 'Can\'t draw on is-bordered' };
    }
    else if (componentPage === undefined) {
        return { flag: 'errPage', message: 'Can not find _component Page' };
    }
    else if (pageFrame === undefined) {
        return { flag: 'errFrame', message: 'Can not find _component frame' };
    }
    else if (baseComponent === undefined) {
        return { flag: 'errComponent', message: 'Can not find Component' };
    }
    let instance;
    if (name === 'Button' || name === 'Field') {
        instance = baseComponent.clone();
    }
    else {
        instance = baseComponent.createInstance();
    }
    selectedObject[0].appendChild(instance);
    return { flag: 'success', message: '' };
};
const addComponents = (msg, name) => {
    const { flag, message } = get$2(name);
    const res = {
        action: 'addComponents',
        flag: flag,
        message: message
    };
    figma.ui.postMessage(res);
};
//# sourceMappingURL=addComponents.js.map

const setColWidth = (col, width = 'fill') => {
    if (width === 'fill') {
        //auto width
        col.layoutGrow = 1;
    }
    else {
        //fixed width
        col.resize(parseInt(width), col.height);
        col.layoutGrow = 0;
    }
};
const setCol = (col, width = 'fill') => {
    if (width === 'fill') {
        //auto width
        col.layoutGrow = 1;
    }
    else {
        //fixed width
        col.resize(parseInt(width), col.height);
        col.layoutGrow = 0;
    }
    col.clipsContent = true;
    col.primaryAxisSizingMode = "FIXED";
    col.primaryAxisAlignItems = "CENTER";
    col.layoutMode = "HORIZONTAL";
    col.layoutPositioning = "AUTO";
    col.layoutAlign = "STRETCH";
    col.counterAxisAlignItems = "CENTER";
    col.counterAxisSizingMode = "FIXED";
    return col;
};
const createTable = (name) => {
    const table = figma.createFrame();
    table.name = name;
    table.clipsContent = true;
    table.primaryAxisAlignItems = "MIN";
    table.layoutPositioning = "AUTO";
    table.counterAxisAlignItems = "MIN";
    if (name === 'tr') {
        table.layoutAlign = "STRETCH";
        table.layoutMode = "HORIZONTAL";
        table.layoutGrow = 0;
        table.primaryAxisSizingMode = "FIXED";
        table.counterAxisSizingMode = "AUTO";
    }
    else if (name === 'table') {
        table.layoutMode = "VERTICAL";
        table.layoutGrow = 1;
        table.primaryAxisSizingMode = "AUTO";
        table.counterAxisSizingMode = "FIXED";
    }
    else {
        table.layoutAlign = "STRETCH";
        table.layoutMode = "VERTICAL";
        table.layoutGrow = 0;
        table.primaryAxisSizingMode = "AUTO";
        table.counterAxisSizingMode = "FIXED";
    }
    return table;
};
const get$3 = (data) => {
    const selectedObject = figma.currentPage.selection;
    const componentPage = figma.root.children.find(el => el.name === '_component');
    const pageFrame = componentPage === null || componentPage === void 0 ? void 0 : componentPage.children.find(el => el.name === '_component');
    const baseComponent = pageFrame === null || pageFrame === void 0 ? void 0 : pageFrame.children.find((el) => el.name === 'table');
    const th = baseComponent === null || baseComponent === void 0 ? void 0 : baseComponent.children.find((el) => el.name === 'th');
    const td = baseComponent === null || baseComponent === void 0 ? void 0 : baseComponent.children.find((el) => el.name === 'td');
    if (selectedObject.length === 0) {
        return { flag: 'errSelect', message: 'Please select frame' };
    }
    else if (selectedObject[0].type !== 'FRAME') {
        return { flag: 'errFrame', message: 'Please select frame' };
    }
    else if (selectedObject[0].name === 'columns') {
        return { flag: 'errFrame', message: 'Can\'t draw on columns' };
    }
    else if (selectedObject[0].name === 'is-bordered') {
        return { flag: 'errFrame', message: 'Can\'t draw on is-bordered' };
    }
    else if (componentPage === undefined) {
        return { flag: 'errPage', message: 'Can not find _component Page' };
    }
    else if (pageFrame === undefined) {
        return { flag: 'errFrame', message: 'Can not find _component frame' };
    }
    else if (baseComponent === undefined) {
        return { flag: 'errComponent', message: 'Can not find Table Component' };
    }
    const table = createTable('table');
    const thead = createTable('thead');
    const tbody = createTable('tbody');
    for (let i = 0; i < data.row; i++) {
        const tr = createTable('tr');
        for (let j = 0; j < data.col; j++) {
            let col;
            if (i === 0) {
                col = setCol(th.clone(), data.colgroup[j].value);
                tr.appendChild(col);
            }
            else {
                col = setCol(td.clone(), data.colgroup[j].value);
                tr.appendChild(col);
            }
        }
        if (i === 0) {
            thead.appendChild(tr);
        }
        else {
            tbody.appendChild(tr);
        }
    }
    table.appendChild(thead);
    table.appendChild(tbody);
    selectedObject[0].appendChild(table);
    return { flag: 'success', message: '' };
};
const addTable = (msg, data) => {
    const { flag, message } = get$3(data);
    const res = {
        action: 'addTable',
        flag: flag,
        message: message
    };
    figma.ui.postMessage(res);
};
//# sourceMappingURL=addTable.js.map

/* eslint-disable no-unsafe-optional-chaining */
const getTable = () => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o;
    let res;
    const selectedObject = figma.currentPage.selection;
    const data = {
        selectTableCheck: false,
        tableCols: 2,
        tableRows: 2,
        tableColGroup: [
            { value: 'fill', selected: 'fill' },
            { value: 'fill', selected: 'fill' }
        ]
    };
    if (((_a = selectedObject[0]) === null || _a === void 0 ? void 0 : _a.name) === 'table'
        && ((_c = (_b = selectedObject[0]) === null || _b === void 0 ? void 0 : _b.children[0]) === null || _c === void 0 ? void 0 : _c.name) === 'thead'
        && ((_f = (_e = (_d = selectedObject[0]) === null || _d === void 0 ? void 0 : _d.children[0]) === null || _e === void 0 ? void 0 : _e.children[0]) === null || _f === void 0 ? void 0 : _f.name) === 'tr'
        && ((_k = (_j = (_h = (_g = selectedObject[0]) === null || _g === void 0 ? void 0 : _g.children[0]) === null || _h === void 0 ? void 0 : _h.children[0]) === null || _j === void 0 ? void 0 : _j.children[0]) === null || _k === void 0 ? void 0 : _k.name) === 'th') {
        const tableColGroup = [];
        for (const th of (_l = selectedObject[0]) === null || _l === void 0 ? void 0 : _l.children[0].children[0].children) {
            const value = th.layoutGrow === 0 ? th.width : 'fill';
            const selected = value === 'fill' ? 'fill' : 'fixed';
            tableColGroup.push({ value, selected });
        }
        data.tableCols = (_m = selectedObject[0]) === null || _m === void 0 ? void 0 : _m.children[0].children[0].children.length;
        data.tableRows = ((_o = selectedObject[0]) === null || _o === void 0 ? void 0 : _o.children[1].children.length) + 1;
        data.tableColGroup = tableColGroup;
        data.selectTableCheck = true;
        res = {
            action: 'getTable',
            flag: 'success',
            data: data
        };
    }
    else {
        data.selectTableCheck = false;
        res = {
            action: 'getTable',
            flag: 'success',
            data: data
        };
    }
    figma.ui.postMessage(res);
};
//# sourceMappingURL=getTable.js.map

/* eslint-disable no-unsafe-optional-chaining */
const setTable = (msg, data) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
    let res;
    const selectedObject = figma.currentPage.selection;
    const componentPage = figma.root.children.find(el => el.name === '_component');
    const pageFrame = componentPage === null || componentPage === void 0 ? void 0 : componentPage.children.find(el => el.name === '_component');
    const baseComponent = pageFrame === null || pageFrame === void 0 ? void 0 : pageFrame.children.find((el) => el.name === 'table');
    const th = baseComponent === null || baseComponent === void 0 ? void 0 : baseComponent.children.find((el) => el.name === 'th');
    const td = baseComponent === null || baseComponent === void 0 ? void 0 : baseComponent.children.find((el) => el.name === 'td');
    if (((_a = selectedObject[0]) === null || _a === void 0 ? void 0 : _a.name) !== 'table') {
        res = { flag: 'errSelect', message: 'Please, select table' };
    }
    else if (((_b = selectedObject[0]) === null || _b === void 0 ? void 0 : _b.children[0].name) !== 'thead') {
        res = { flag: 'errSelect', message: 'Invalid table format(thead)' };
    }
    else if (((_c = selectedObject[0]) === null || _c === void 0 ? void 0 : _c.children[1].name) !== 'tbody') {
        res = { flag: 'errSelect', message: 'Invalid table format(tbody)' };
    }
    else if (((_d = selectedObject[0]) === null || _d === void 0 ? void 0 : _d.children[0].children[0].name) !== 'tr') {
        res = { flag: 'errSelect', message: 'Invalid table format(tr)' };
    }
    else if (((_e = selectedObject[0]) === null || _e === void 0 ? void 0 : _e.children[0].children[0].children[0].name) !== 'th') {
        res = { flag: 'errSelect', message: 'Invalid table format(th)' };
    }
    else if (componentPage === undefined) {
        res = { flag: 'errPage', message: 'Can not find _component Page' };
    }
    else if (pageFrame === undefined) {
        res = { flag: 'errFrame', message: 'Can not find _component frame' };
    }
    else if (baseComponent === undefined) {
        res = { flag: 'errComponent', message: 'Can not find Table Component' };
    }
    else {
        const thead = (_f = selectedObject[0]) === null || _f === void 0 ? void 0 : _f.children[0];
        const tbody = (_g = selectedObject[0]) === null || _g === void 0 ? void 0 : _g.children[1];
        const oldCols = thead.children[0];
        const oldColsCount = oldCols.children.length;
        const tbodyCount = tbody.children.length;
        //삭제시 
        //기존 테이블보다 row 갯수가 작으면 오버되는 것 삭제
        if (data.row <= tbodyCount) {
            for (let i = tbodyCount; i >= data.row; i--) {
                tbody.children[i - 1].remove();
            }
        }
        //기존 테이블보다 col 갯수가 작으면 오버되는 것 삭제
        if (data.col < oldColsCount) {
            //th
            for (let j = oldColsCount; j > data.col; j--) {
                (_j = (_h = thead.children[0]) === null || _h === void 0 ? void 0 : _h.children[j - 1]) === null || _j === void 0 ? void 0 : _j.remove();
            }
            //td
            for (let i = 0; i < data.row - 1; i++) {
                for (let j = oldColsCount; j > data.col; j--) {
                    (_l = (_k = tbody.children[i]) === null || _k === void 0 ? void 0 : _k.children[j - 1]) === null || _l === void 0 ? void 0 : _l.remove();
                }
            }
        }
        //컬럼 속성 변경 및 생성
        for (let i = 0; i < data.row; i++) {
            let tr;
            if (i > tbodyCount) {
                tr = createTable('tr');
                tbody.appendChild(tr);
            }
            for (let j = 0; j < data.col; j++) {
                let col;
                if (i === 0) {
                    if (j >= oldColsCount) {
                        col = setCol(th.clone(), data.colgroup[j].value);
                        thead.children[0].appendChild(col);
                    }
                    else {
                        setColWidth(thead.children[0].children[j], data.colgroup[j].value);
                    }
                }
                else {
                    if (j >= oldColsCount || i > tbodyCount) {
                        col = setCol(td.clone(), data.colgroup[j].value);
                        tbody.children[i - 1].appendChild(col);
                    }
                    else {
                        setColWidth(tbody.children[i - 1].children[j], data.colgroup[j].value);
                    }
                }
            }
        }
        res = {
            action: 'setTable',
            flag: 'success'
        };
    }
    figma.ui.postMessage(res);
};
//# sourceMappingURL=setTable.js.map

/* eslint-disable no-unsafe-optional-chaining */
const removeTableColumn = (msg, data) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
    let res;
    const selectedObject = figma.currentPage.selection;
    const componentPage = figma.root.children.find(el => el.name === '_component');
    const pageFrame = componentPage === null || componentPage === void 0 ? void 0 : componentPage.children.find(el => el.name === '_component');
    const baseComponent = pageFrame === null || pageFrame === void 0 ? void 0 : pageFrame.children.find((el) => el.name === 'table');
    if (((_a = selectedObject[0]) === null || _a === void 0 ? void 0 : _a.name) !== 'table') {
        res = { flag: 'errSelect', message: 'Please, select table' };
    }
    else if (((_b = selectedObject[0]) === null || _b === void 0 ? void 0 : _b.children[0].name) !== 'thead') {
        res = { flag: 'errSelect', message: 'Invalid table format(thead)' };
    }
    else if (((_c = selectedObject[0]) === null || _c === void 0 ? void 0 : _c.children[1].name) !== 'tbody') {
        res = { flag: 'errSelect', message: 'Invalid table format(tbody)' };
    }
    else if (((_d = selectedObject[0]) === null || _d === void 0 ? void 0 : _d.children[0].children[0].name) !== 'tr') {
        res = { flag: 'errSelect', message: 'Invalid table format(tr)' };
    }
    else if (((_e = selectedObject[0]) === null || _e === void 0 ? void 0 : _e.children[0].children[0].children[0].name) !== 'th') {
        res = { flag: 'errSelect', message: 'Invalid table format(th)' };
    }
    else if (componentPage === undefined) {
        res = { flag: 'errPage', message: 'Can not find _component Page' };
    }
    else if (pageFrame === undefined) {
        res = { flag: 'errFrame', message: 'Can not find _component frame' };
    }
    else if (baseComponent === undefined) {
        res = { flag: 'errComponent', message: 'Can not find Table Component' };
    }
    else {
        const thead = (_f = selectedObject[0]) === null || _f === void 0 ? void 0 : _f.children[0];
        const tbody = (_g = selectedObject[0]) === null || _g === void 0 ? void 0 : _g.children[1];
        const tbodyCount = tbody.children.length;
        //th
        (_j = (_h = thead.children[0]) === null || _h === void 0 ? void 0 : _h.children[data]) === null || _j === void 0 ? void 0 : _j.remove();
        //td
        for (let i = 0; i < tbodyCount; i++) {
            (_l = (_k = tbody.children[i]) === null || _k === void 0 ? void 0 : _k.children[data]) === null || _l === void 0 ? void 0 : _l.remove();
        }
        getTable();
        res = {
            action: 'removeTableColumn',
            flag: 'success'
        };
    }
    figma.ui.postMessage(res);
};
//# sourceMappingURL=removeTableColumn.js.map

const changeTableOrder = (msg, data) => {
    var _a, _b, _c, _d, _e, _f, _g;
    let res;
    const selectedObject = figma.currentPage.selection;
    if (((_a = selectedObject[0]) === null || _a === void 0 ? void 0 : _a.name) !== 'table') {
        res = { flag: 'errSelect', message: 'Please, select table' };
    }
    else if (((_b = selectedObject[0]) === null || _b === void 0 ? void 0 : _b.children[0].name) !== 'thead') {
        res = { flag: 'errSelect', message: 'Invalid table format(thead)' };
    }
    else if (((_c = selectedObject[0]) === null || _c === void 0 ? void 0 : _c.children[1].name) !== 'tbody') {
        res = { flag: 'errSelect', message: 'Invalid table format(tbody)' };
    }
    else if (((_d = selectedObject[0]) === null || _d === void 0 ? void 0 : _d.children[0].children[0].name) !== 'tr') {
        res = { flag: 'errSelect', message: 'Invalid table format(tr)' };
    }
    else if (((_e = selectedObject[0]) === null || _e === void 0 ? void 0 : _e.children[0].children[0].children[0].name) !== 'th') {
        res = { flag: 'errSelect', message: 'Invalid table format(th)' };
    }
    else {
        const thead = (_f = selectedObject[0]) === null || _f === void 0 ? void 0 : _f.children[0];
        const tbody = (_g = selectedObject[0]) === null || _g === void 0 ? void 0 : _g.children[1];
        const tbodyCount = tbody.children.length;
        //thead
        const tmp = thead.children[0].children[data.start].clone();
        thead.children[0].children[data.start].remove();
        thead.children[0].insertChild(data.target, tmp);
        //tbody
        for (let i = 0; i < tbodyCount; i++) {
            const tmp = tbody.children[i].children[data.start].clone();
            tbody.children[i].children[data.start].remove();
            tbody.children[i].insertChild(data.target, tmp);
        }
        res = {
            action: 'changeTableOrder',
            flag: 'success'
        };
    }
    figma.ui.postMessage(res);
};
//# sourceMappingURL=changeTableOrder.js.map

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

/* eslint-disable no-unsafe-optional-chaining */
const getMarker = () => {
    var _a;
    const data = {
        selectMarkerCheck: false,
        markerText: null,
        descriptionText: null,
        markerColor: null
    };
    let res = {
        action: 'getMarker',
        flag: 'success',
        data: data
    };
    const selectedObject = figma.currentPage.selection;
    if (selectedObject.length > 0) {
        const [node] = getFrameTop(selectedObject[0]);
        if (node.type !== 'TEXT') {
            const descriptionFrame = node === null || node === void 0 ? void 0 : node.findChild(el => el.name == '_description');
            if (((_a = selectedObject[0]) === null || _a === void 0 ? void 0 : _a.getPluginDataKeys().includes('id')) && descriptionFrame !== null) {
                const id = selectedObject[0].getPluginData('id');
                if (!!descriptionFrame.getPluginData(id) === true) { //삭제가 아니면
                    const tmp = JSON.parse(descriptionFrame.getPluginData(id));
                    //변경되었는지 체크
                    const listFrame = descriptionFrame.findChild(el => el.name == 'list');
                    const markerText = listFrame.children.find(el => el.getPluginData('id') === id).children[0].children[1].characters;
                    const descriptionText = listFrame.children.find(el => el.getPluginData('id') === id).children[1].characters;
                    if (tmp.markerText !== markerText || tmp.descriptionText !== descriptionText) {
                        const data = {
                            markerText,
                            descriptionText
                        };
                        descriptionFrame.setPluginData(id, JSON.stringify(data));
                    }
                    data.selectMarkerCheck = true;
                    data.markerText = tmp.markerText;
                    data.descriptionText = tmp.descriptionText;
                    data.markerColor = tmp.markerColor;
                }
                res = {
                    action: 'getMarker',
                    flag: 'success',
                    data: data
                };
            }
        }
    }
    figma.ui.postMessage(res);
};
//# sourceMappingURL=getMarker.js.map

const getFrameTop = (node, x = 0, y = 0) => {
    if (node.parent.type === 'PAGE') {
        return [
            node,
            x,
            y
        ];
    }
    else {
        x += node.x;
        y += node.y;
        return getFrameTop(node.parent, x, y);
    }
};
const loadFonts = () => __awaiter(void 0, void 0, void 0, function* () {
    yield figma.loadFontAsync({ family: "Inter", style: "Regular" });
    yield figma.loadFontAsync({ family: "Inter", style: "Bold" });
});
const get$4 = (data) => __awaiter(void 0, void 0, void 0, function* () {
    const componentPage = figma.root.children.find(el => el.name === '_component');
    const pageFrame = componentPage === null || componentPage === void 0 ? void 0 : componentPage.children.find(el => el.name === '_markers');
    const marker = pageFrame === null || pageFrame === void 0 ? void 0 : pageFrame.children.find(el => el.name === 'marker');
    const descriptionItem = pageFrame === null || pageFrame === void 0 ? void 0 : pageFrame.children.find(el => el.name === 'descriptionItem');
    const selectedObject = figma.currentPage.selection;
    if (selectedObject.length === 0) {
        return { flag: 'errSelect', message: 'Please select object' };
    }
    const id = selectedObject[0].id;
    const [node, x, y] = getFrameTop(selectedObject[0]);
    if (node.type !== 'FRAME') {
        return { flag: 'errFrame', message: 'Please select frame or instance' };
    }
    else if (data.markerText.length < 1) {
        return { flag: 'errText', message: 'Please write Marker text' };
    }
    else if (data.descriptionText.length < 1) {
        return { flag: 'errText', message: 'Please write description text' };
    }
    else if (componentPage === undefined) {
        return { flag: 'errPage', message: 'Can not find _component Page' };
    }
    else if (pageFrame === undefined) {
        return { flag: 'errFrame', message: 'Can not find _markers frame' };
    }
    else if (marker === undefined) {
        return { flag: 'errComponent', message: 'Can not find marker' };
    }
    //description 그룹 있는지 체크
    let descriptionFrame = node.findChild(el => el.name == '_description');
    if (descriptionFrame === null) {
        const tmp = figma.createFrame();
        tmp.name = '_description';
        tmp.locked = true;
        tmp.fills = [];
        tmp.resize(node.width, node.height);
        tmp.clipsContent = false;
        node.appendChild(tmp);
        descriptionFrame = node.findChild(el => el.name == '_description');
        if (node.layoutMode !== 'NONE') {
            descriptionFrame.layoutPositioning = "ABSOLUTE";
        }
        descriptionFrame.x = 0;
        descriptionFrame.y = 0;
    }
    //list 있는지 체크
    let listFrame = descriptionFrame.findChild(el => el.name == 'list');
    if (listFrame === null) {
        const tmp = figma.createFrame();
        tmp.name = 'list';
        tmp.x = descriptionFrame.width + 50;
        tmp.resize(300, tmp.height);
        tmp.cornerRadius = 10;
        tmp.paddingTop = 10;
        tmp.paddingBottom = 10;
        tmp.paddingLeft = 10;
        tmp.paddingRight = 10;
        tmp.itemSpacing = 10;
        tmp.clipsContent = true;
        tmp.primaryAxisAlignItems = "MIN";
        tmp.layoutPositioning = "AUTO";
        tmp.layoutAlign = "STRETCH";
        tmp.counterAxisAlignItems = "MIN";
        tmp.layoutMode = "VERTICAL";
        tmp.layoutGrow = 1;
        tmp.primaryAxisSizingMode = "AUTO";
        tmp.counterAxisSizingMode = "FIXED";
        descriptionFrame.appendChild(tmp);
        listFrame = descriptionFrame.findChild(el => el.name == 'list');
    }
    //markers 있는지 체크
    let markersFrame = descriptionFrame.findChild(el => el.name == 'markers');
    if (markersFrame === null) {
        const tmp = figma.createFrame();
        tmp.name = 'markers';
        tmp.resize(node.width, node.height);
        tmp.fills = [];
        tmp.clipsContent = false;
        descriptionFrame.appendChild(tmp);
        markersFrame = descriptionFrame.findChild(el => el.name === 'markers');
    }
    let color = { r: 1, g: 0, b: 0 };
    switch (data.markerColor) {
        case 'yellow':
            color = { r: 0.9882, g: 0.7254, b: 0 };
            break;
        case 'green':
            color = { r: 0.2941, g: 0.7843, b: 0.4313 };
            break;
        case 'blue':
            color = { r: 0.2039, g: 0.5019, b: 0.8196 };
            break;
    }
    //marker 있는지 체크
    const checkMarker = descriptionFrame.getPluginDataKeys().includes(id);
    if (!checkMarker) {
        //없으면 양쪽에 추가
        const tmp1 = marker.createInstance();
        tmp1.name = `marker - ${data.markerText}`;
        tmp1.x = x - 20;
        tmp1.y = y - 20;
        tmp1.children.find(el => el.type === 'ELLIPSE').fills = [{
                type: "SOLID",
                blendMode: "NORMAL",
                opacity: 1,
                visible: true,
                color: color
            }];
        const tmp2 = descriptionItem.createInstance();
        tmp2.name = `descriptionItem - ${data.markerText}`;
        tmp2.children[0].children.find(el => el.type === 'ELLIPSE').fills = [{
                type: "SOLID",
                blendMode: "NORMAL",
                opacity: 1,
                visible: true,
                color: color
            }];
        tmp1.setPluginData('id', id);
        tmp2.setPluginData('id', id);
        selectedObject[0].setPluginData('id', id);
        yield loadFonts().then(() => {
            tmp1.children[1].characters = data.markerText;
            markersFrame.appendChild(tmp1);
            tmp2.children[0].children[1].characters = data.markerText;
            tmp2.children[1].characters = data.descriptionText;
            listFrame.appendChild(tmp2);
        });
    }
    else {
        //이미 있으면
        yield loadFonts().then(() => {
            markersFrame.children.find(el => el.getPluginData('id') === id).children[1].characters = data.markerText;
            markersFrame.children.find(el => el.getPluginData('id') === id).children[0].fills = [{
                    type: "SOLID",
                    blendMode: "NORMAL",
                    opacity: 1,
                    visible: true,
                    color: color
                }];
            listFrame.children.find(el => el.getPluginData('id') === id).children[0].children[1].characters = data.markerText;
            listFrame.children.find(el => el.getPluginData('id') === id).children[0].children[0].fills = [{
                    type: "SOLID",
                    blendMode: "NORMAL",
                    opacity: 1,
                    visible: true,
                    color: color
                }];
            listFrame.children.find(el => el.getPluginData('id') === id).children[1].characters = data.descriptionText;
        });
    }
    //새로 입력된 데이터 저장
    yield descriptionFrame.setPluginData(id, JSON.stringify(data));
    getMarker();
    return { flag: 'success', message: '' };
});
const addMarker = (msg, data) => __awaiter(void 0, void 0, void 0, function* () {
    const { flag, message } = yield get$4(data);
    const res = {
        action: 'addMarker',
        flag: flag,
        message: message
    };
    figma.ui.postMessage(res);
});
//# sourceMappingURL=addMarker.js.map

const get$5 = () => {
    const selectedObject = figma.currentPage.selection;
    if (selectedObject.length === 0) {
        return { flag: 'errSelect', message: 'Please select object' };
    }
    const id = selectedObject[0].getPluginData('id');
    const [node] = getFrameTop(selectedObject[0]);
    if (node.type !== 'FRAME') {
        return { flag: 'errFrame', message: 'Please select frame or instance' };
    }
    const descriptionFrame = node.findChild(el => el.name == '_description');
    const listFrame = descriptionFrame.findChild(el => el.name == 'list');
    const markersFrame = descriptionFrame.findChild(el => el.name == 'markers');
    markersFrame.findChild(el => el.getPluginData('id') === id).remove();
    listFrame.findChild(el => el.getPluginData('id') === id).remove();
    //원본 id 정보도 삭제
    node.findAll(el => el.getPluginData('id') === id)[0].setPluginData('id', '');
    descriptionFrame.setPluginData(id, '');
    getMarker();
    return { flag: 'success', message: '' };
};
const removeMarker = (msg) => {
    const { flag, message } = get$5();
    const res = {
        action: 'removeMarker',
        flag: flag,
        message: message
    };
    figma.ui.postMessage(res);
};
//# sourceMappingURL=removeMarker.js.map

figma.showUI(__html__, { themeColors: true, width: 320, height: 400 });
figma.ui.onmessage = msg => {
    if (msg.type === 'getCode') {
        getCode(msg);
    }
    else if (msg.type === 'addPage') {
        addPage(msg, msg.data);
    }
    else if (msg.type === 'drawGrid') {
        drawGrid(msg, msg.data);
    }
    else if (msg.type === 'drawBorderBox') {
        drawBorderBox();
    }
    else if (msg.type === 'getInfo') {
        getInfo();
    }
    else if (msg.type === 'addComponents') {
        addComponents(msg, msg.data);
    }
    else if (msg.type === 'addTable') {
        addTable(msg, msg.data);
    }
    else if (msg.type === 'setTable') {
        setTable(msg, msg.data);
    }
    else if (msg.type === 'removeTableColumn') {
        removeTableColumn(msg, msg.data);
    }
    else if (msg.type === 'changeTableOrder') {
        changeTableOrder(msg, msg.data);
    }
    else if (msg.type === 'addMarker') {
        addMarker(msg, msg.data);
    }
    else if (msg.type === 'removeMarker') {
        removeMarker();
    }
    else if (msg.type === 'error') {
        figma.notify(msg.message, {
            timeout: 3000,
            error: true
        });
    }
    else {
        console.log(msg);
    }
};
figma.on('selectionchange', () => {
    var _a, _b, _c;
    const lastSelection = figma.currentPage.selection[0];
    const lastSelectionParent = (_b = (_a = figma.currentPage.selection[0]) === null || _a === void 0 ? void 0 : _a.parent) === null || _b === void 0 ? void 0 : _b.id;
    if (lastSelection) {
        getTable();
        getMarker();
    }
    if (((_c = lastSelection === null || lastSelection === void 0 ? void 0 : lastSelection.parent) === null || _c === void 0 ? void 0 : _c.type) === 'PAGE' || lastSelection === null) {
        figma.currentPage.setPluginData('sadmin-last-selection', '');
    }
    else if (lastSelectionParent) {
        figma.currentPage.setPluginData('sadmin-last-selection', lastSelectionParent);
    }
});
// figma.on("documentchange", (event) => {
// 	for (const change of event.documentChanges) {
// 		switch (change.type) {
// 			case "DELETE":
// 				// eslint-disable-next-line no-case-declarations
// 				const lastSelectionParent = figma.currentPage.getPluginData('sadmin-last-selection');
// 				if(lastSelectionParent !== '' && lastSelectionParent !== null){
// 					detectDeleteMarker(lastSelectionParent);
// 				}
// 				break;
// 		}
// 	}
// });
//# sourceMappingURL=code.js.map
